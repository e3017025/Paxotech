package POMTest;

import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import POMClass.BaseClass;
import POMClass.LoginPage;
import POMClass.SearchPage;


public class SearchTest extends BaseClass {
	
	@BeforeTest
	public void LaunchApplication()
	{
		
		try
		{
			launchUrl();
		} catch (IOException | InterruptedException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	
	@Test
	public void AmazonSearch() throws IOException, InterruptedException
	{
		
		LoginPage loginpage = new LoginPage();
		String Amazonval = loginpage.AmazonPrime.getText().toString();
		//Verifying the Amazon is Displayed on the top left corner of the page
		assertEquals(Amazonval, loginpage.Amazonwindow);
		loginpage.ClickElement(loginpage.All_SelectIcon);
		Thread.sleep(3000);
		loginpage.selectDropDown_Index(loginpage.All_SelectIcon, 10);
		loginpage.EnterText(loginpage.SearchText, "Catalog");
		loginpage.ClickElement(loginpage.Searchbutton);
		
		//Verifying the Amazon is Displayed on the top left corner of the page
		assertEquals(Amazonval, loginpage.Amazonwindow);
		SearchPage searchpage = new SearchPage();
		
		// Verify the Links listed above Data Catalog
		String advancedsearch = searchpage.Advanced_search.getText().toString();
		assertEquals(advancedsearch, "Advanced Search");
		
		String NewReleaseandOrders = searchpage.NewRelease.getText().toString();
		assertEquals(NewReleaseandOrders, "New Releases & Pre-orders");
		
		String Bestsellers = searchpage.Bestsellers.getText().toString();
		assertEquals(Bestsellers, "Best Sellers");
		
		String BrowseGeners = searchpage.Browse_genes.getText().toString();
		assertEquals(BrowseGeners, "Browse Genres");
		
		String ChildrenAndAdult = searchpage.Childrenandyoung.getText().toString();
		assertEquals(ChildrenAndAdult, "Children's & Young Adult");
		
		//Assiging the values to ArrayList
		ArrayList<HashMap> arr1 = searchpage.GetBookNames();
		
		for (int k=0 ;k<=arr1.size();k++)
		{
			//Printing the Book names from Hashmap from each arrray list item
			System.out.println(arr1.get(k).get("BookName"));
			//arr1.get(k).get("Authorname");
		}
		
	}
	
	
	@AfterMethod
	public void afterMethod()
	{
		
		closeBrowsers();
	}

}
