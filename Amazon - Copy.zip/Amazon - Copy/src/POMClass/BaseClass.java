package POMClass;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.os.WindowsUtils;


public class BaseClass {
	
	public static WebDriver driver;
	public static String amazonurl = "https://www.amazon.in/";
	
	
	public static void launchUrl() throws IOException, InterruptedException {
		try {
			driver.quit();
		}
		catch(Exception e) {
			
		}
		
		try {
			System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.get(amazonurl);
			driver.manage().window().maximize();
			Thread.sleep(3000);
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	public void closeBrowsers() {
		try {
			driver.close();
			WindowsUtils.killByName("ChromeDriver.exe");
			Runtime.getRuntime().exec("taskkill /F /IM Chrome.exe");
		}
		catch(Exception e) {
			
		}
	}
	

}
