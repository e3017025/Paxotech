package POMClass;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class SearchPage extends BaseClass {
	
	private By advanced_search=By.xpath("//*[@id='nav-subnav']/a[2]/span");
	private By newRelease = By.xpath("//*[@id='nav-subnav']/a[3]/span");
	private By bestsellers = By.xpath("//*[@id='nav-subnav']/a[4]/span[1]");
	private By browse_genes = By.xpath("//*[@id='nav-subnav']/a[5]/span[1]");	
	private By childrenandyoung = By.xpath("//*[@id='nav-subnav']/a[6]/span[1]");
	private By allIndianLanguages = By.xpath("//*[@id='nav-subnav']/a[9]/span[1]");
	
	
	private By bookname = By.xpath("//*[@id=\'result_0\']/div/div/div/div[2]/div[1]/div[1]/a/h2");
	private By lastpage = By.xpath("//*[@id=\'pagn\']/span[7]");
	
	public WebElement Advanced_search,NewRelease,Bestsellers,Browse_genes,Childrenandyoung,AllIndianLanguages;
	
	public SearchPage()
	{
		
		Advanced_search = driver.findElement(advanced_search);
		NewRelease = driver.findElement(newRelease);
		Bestsellers = driver.findElement(bestsellers);
		Browse_genes = driver.findElement(browse_genes);
		Childrenandyoung = driver.findElement(childrenandyoung);
		AllIndianLanguages = driver.findElement(allIndianLanguages);
		
	}
	
	public static  ArrayList<HashMap> GetBookNames() throws InterruptedException
	
	{
		ArrayList<HashMap> Arr = new ArrayList<>();
		
		// Iterating till the "LastPage" is Disabled	
		while(driver.findElement(By.xpath("//*[@id=\'pagn\']/span[7]")).isEnabled()== true) 
		{
			//Maximum number of rows
			int Max = 15;
			
		int i=0;
		for (int j=0 ;j<=Max;j++)
			{
			 
				LinkedHashMap<String,String> map =new LinkedHashMap<String,String>();
				String bookname = driver.findElement(By.xpath("//*[@id=\'result_"+j+"\']/div/div/div/div[2]/div[1]/div[1]/a/h2")).getText();
				
				//String Authorname = driver.findElement(By.xpath("//*[@id=\'result_"+j+"\']/div/div/div/div[2]/div[1]/div[2]/span[2]")).getText();
				//writing to Hashmap
				map.put("BookName", bookname);
				//map.put("Authorname",Authorname);
				
				//Adding to ArrayList				
				Arr.add(map);
				 i++;
				if (j>=Max)
				{
					j=Max+1;
					Max = j+Max;
					driver.findElement(By.id("pagnNextString")).click();
					Thread.sleep(3000);
				}
			}
			
			
				
	 }
						
		//System.out.println(Arr);
		//Returing the Arraylist
		return Arr;
		
	}
	

	
	

}
