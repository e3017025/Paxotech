package POMClass;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.Select;

public class LoginPage extends BaseClass
{
	
	private By searchText = By.id("twotabsearchtextbox");
	private By all_SelectIcon = By.id("searchDropdownBox");
	private By selectAddress = By.id("glow-ingress-line1");
	private By signIn = By.xpath("//*[@id=\'nav-link-yourAccount\']/span[1]");
	private By yourList = By.xpath("//*[@id=\'nav-link-wishlist\']/span[2]");
	private By cart = By.id("nav-cart-count");
	private By searchbutton = By.xpath("//*[@id=\'nav-search\']/form/div[2]/div/input");
	
	
	private By amazonPrime = By.xpath("//*[@id='nav-logo']/a[1]/span[1]");
	
	public static String Amazonwindow = "Amazon";
	
	public WebElement SearchText,All_SelectIcon,SelectAddress,SignIn,YourList,Cart,Searchbutton,AmazonPrime;
	
	public LoginPage ()
	{
		
	//Constructor Defined to verify the objects in LoginPage
			try
			{
				//WebDriverWait wait = new WebDriverWait(driver, 90);
				//wait.until(ExpectedConditions.visibilityOfElementLocated(all_SelectIcon));
				SearchText = driver.findElement(searchText);
				All_SelectIcon = driver.findElement(all_SelectIcon);
				SelectAddress = driver.findElement(selectAddress);
				SignIn = driver.findElement(signIn);
				YourList =driver.findElement(yourList);
				Cart = driver.findElement(cart);
				Searchbutton = driver.findElement(searchbutton);
				AmazonPrime =driver.findElement(amazonPrime);
				
			}
			
			catch(Exception e)
			{
				System.out.println(e);
			}
		
		}
	
	
	 public void selectDropDown_Index(WebElement element, int index)
	 {
		 
		 Select select = new Select(element);
		 select.selectByIndex(index);	   
	   }

	 public void selectDropDownByValue(WebElement element, String text)
	 {
		 
		 Select select = new Select(element);
		 select.selectByValue(text);	   
	   }
	 public void ClickElement(WebElement element)
	 {
		 element.click();
	 }
   public void EnterText(WebElement element, String text)
   {
	   element.sendKeys(text);
   }

}


