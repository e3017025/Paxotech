package com.AutomationDemo.Paxotech.pageObjects.kids;

import org.openqa.selenium.By;
import com.AutomationDemo.Paxotech.helperClasses.BaseClass;

public class ToysAndGamesElements extends BaseClass{

	

	//Featured in Kids

	//Ages	
	public static By link0To2years=By.xpath("//nav[@id='refinements']//h2[text()='Ages']/following-sibling::dl[1]//a[text()='0 - 2 Years']");
	public static By link3To5years=By.xpath("//nav[@id='refinements']//h2[text()='Ages']/following-sibling::dl[1]//a[text()='3 - 5 Years']");
	public static By link6To8years=By.xpath("//nav[@id='refinements']//h2[text()='Ages']/following-sibling::dl[1]//a[text()='6 - 8 Years']");
	public static By link9To12years=By.xpath("//nav[@id='refinements']//h2[text()='Ages']/following-sibling::dl[1]//a[text()='9 - 12 Years']");
	public static By linkTeens=By.xpath("//nav[@id='refinements']//h2[text()='Ages']/following-sibling::dl[1]//a[text()='Teen']");

	//Brands	
	public static By linkALEX=By.xpath("//nav[@id='refinements']//h2[text()='Brands']/following-sibling::dl[1]//a[text()='ALEX']"); 	 	
	public static By linkEspariDolls=By.xpath("//nav[@id='refinements']//h2[text()='Brands']/following-sibling::dl[1]//a[text()='espari™ Dolls']");

	//Characters	
	public static By linkBarbie=By.xpath("//nav[@id='refinements']//h2[text()='Characters']/following-sibling::dl[1]//a[text()='Barbie']");
	public static By linkCalicoCritters=By.xpath("//nav[@id='refinements']//h2[text()='Characters']/following-sibling::dl[1]//a[text()='Calico Critters']");	
	
	//Refine by Categories	
	public static By linkArtsAndCrafts=By.xpath("//nav[@id='refinements']//div[@class='refinement']//div[@class='refinements']/h2[text()='Categories']//..//dl[1]//a[text()='Arts & Crafts']");	
	public static By linkBabyBoutique=By.xpath("//nav[@id='refinements']//div[@class='refinement']//div[@class='refinements']/h2[text()='Categories']//..//dl[1]//a[text()='Baby Boutique']");
	public static By linkShowMore=By.xpath("//nav[@id='refinements']//div[@class='refinement']//div[@class='refinements']/h2[text()='Categories']//..//dl[1]//dd[@class='viewMoreviewLessToggle']/a[text()='Show More']");
	

	//Prices
	public static By linkUnderDoller5=By.xpath("//nav[@id='refinements']//div[@class='refinement']/div[@class='refinements']/h2[text()='Prices']//..//dl[1]//dd//a[text()='Under $5']");
	public static By linkDoller5To10=By.xpath("//nav[@id='refinements']//div[@class='refinement']/div[@class='refinements']/h2[text()='Prices']//..//dl[1]//dd//a[text()='$5 - $10']");
	
	//Shop by Category	
	
	public static String featuredcatategoryXpath="//section[@class='featuredCategories featured-subjects']/h2[text()='Shop by Category']/..//div[@class='featured-categories-container']/div[@class='featured-category']";
	
	//Shop by Category
	
	//Building & LEGO
	
	public static By linkBlocks=By.xpath(featuredcatategoryXpath+"/figcaption/a[text()='Building & LEGO']/../following-sibling::div/a[text()='Blocks']");
	public static By linkCreativeBuilding=By.xpath(featuredcatategoryXpath+"/figcaption/a[text()='Building & LEGO']/../following-sibling::div/a[text()='Creative Building']");
	
	//Dolls & Stuffed Animals
	
	public static By linkShopByCategory_Barbie=By.xpath(featuredcatategoryXpath+"/figcaption/a[text()='Dolls & Stuffed Animals']/../following-sibling::div/a[text()='Barbie']");
	
	
}
