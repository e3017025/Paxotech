package com.AutomationDemo.Paxotech.testscripts.sanity;

import org.openqa.selenium.By;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.AutomationDemo.Paxotech.helperClasses.BaseClass;
import com.AutomationDemo.Paxotech.pageObjects.HomePageElements;

public class FooterValidation extends BaseClass{
	
	@DataProvider(name = "sanityFooterdata-source")
	public Object[][] allFooterElementsInOneShot() {
		return new Object[][] {
			{ "ImageVistYourLocalStore",HomePageElements.imgVistYourLocalStore},
			{ "ImgGiftCards",HomePageElements.imgGiftCards}			
		};
	}

	@Test(dataProvider = "sanityFooterdata-source")
	public void verifyWebElementsInFooter(String objectName,By xpath) {		
		objectFinder(driver, xpath);		
	}

}
