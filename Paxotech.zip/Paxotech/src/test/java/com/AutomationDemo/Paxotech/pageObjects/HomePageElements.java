package com.AutomationDemo.Paxotech.pageObjects;

import org.openqa.selenium.By;
import com.AutomationDemo.Paxotech.helperClasses.BaseClass;

public class HomePageElements extends BaseClass{
	
	public static By linkSignIn=By.xpath("//a[@id='signInLink']");
	
	public static By inputEmail=By.cssSelector("#email");
	
	public static By inputPassword=By.cssSelector("#password");
	
	public static By inputSecureSignIn=By.xpath("//input[@value='Secure Sign In']");
	
	public static By inputSearch=By.xpath("//input[@id='searchBarBN']");
	
	public static By inputsearchSubmit=By.xpath("//input[@id='searchSubmit']");
	
	
	public static By SignInWindowIframe=By.xpath("//iframe[@src='/account/login-frame.jsp?tplName=login&parentUrl=http%3a%2f%2fwww.barnesandnoble.com%2f&isCheckout=&isNookLogin=&isEgift=']");
	

	//Header Objects
	
	public static By linkHeaderSignIn=By.xpath("//header[@id='globalHeader']//a[@id='signInLink']");
	public static By searcBar=By.xpath("//div[@id='logoContainer']");	
	
	// Footer Objects
	
	public static By imgVistYourLocalStore=By.xpath("//div[@class='global-footer-promo-row']//img[@title='Visit Your Local Store']");
	public static By imgGiftCards=By.xpath("//div[@class='global-footer-promo-row']//img[@title='Gift Cards']");
	
	
}
