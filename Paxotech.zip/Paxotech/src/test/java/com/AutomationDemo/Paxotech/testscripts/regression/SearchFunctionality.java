package com.AutomationDemo.Paxotech.testscripts.regression;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.AutomationDemo.Paxotech.helperClasses.BaseClass;
import com.AutomationDemo.Paxotech.pageObjects.CommonElements;
import com.AutomationDemo.Paxotech.pageObjects.HomePageElements;

public class SearchFunctionality extends BaseClass{
	
	@Test
	public void search(){
		
		objectFinder(driver, HomePageElements.inputSearch).sendKeys("barbie");
		objectFinder(driver, HomePageElements.inputsearchSubmit).click();		
		Assert.assertTrue(objectExists(driver, CommonElements.firstProductImageInResultPage), "There are no products with barbie");

	}
	

}
