package com.AutomationDemo.Paxotech.testscripts.regression.kids;

import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.AutomationDemo.Paxotech.helperClasses.BaseClass;
import com.AutomationDemo.Paxotech.helperClasses.ReadXlsxDataHelper;
import com.AutomationDemo.Paxotech.pageObjects.CommonElements;
import com.AutomationDemo.Paxotech.pageObjects.PrimaryNavigationElements;
import com.AutomationDemo.Paxotech.pageObjects.ProductSummaryPage;
import com.AutomationDemo.Paxotech.pageObjects.ShippingAddress;
import com.AutomationDemo.Paxotech.pageObjects.kids.ToysAndGamesElements;

public class TC_Kids_ToysAndGamesPurchasebarby extends BaseClass{
	
	HashMap shppingAddresshsMapObj;
	
	@BeforeClass
	public void navigateToToysAndGameHomePage() throws InterruptedException{				
		Actions actions = new Actions(driver);
		actions.moveToElement(objectFinder(driver, PrimaryNavigationElements.linkKids)).build().perform();		
		Thread.sleep(3000);
		objectFinder(driver, PrimaryNavigationElements.linkToysAndGames,10).click();			
	
	}	

	@Test
	public void selectBarbie() throws Exception{
		
		objectFinder(driver, ToysAndGamesElements.linkShopByCategory_Barbie,90).click();
		
		String imgSrcInSearchResults=objectFinder(driver, CommonElements.firstProductImageInResultPage).getAttribute("src");
		
		objectFinder(driver, CommonElements.firstProductLinkInResultPage).click();
		
		String imgSrcInSummaryPage=objectFinder(driver, CommonElements.productImageInSummaryPage).getAttribute("src");
		
		Assert.assertTrue(imageSrcByRemovingSizeParameters(imgSrcInSearchResults).equalsIgnoreCase(imageSrcByRemovingSizeParameters(imgSrcInSummaryPage)), "Image src in SearchResults Page is not equal with Product Summary Page");
		
		objectFinder(driver, ProductSummaryPage.inputAddToBag).click();
		
		objectFinder(driver, ProductSummaryPage.linkViewShoppingBagg).click();
		
		objectFinder(driver, ProductSummaryPage.linkcontinue).click();
		
		objectFinder(driver, ProductSummaryPage.linkAddShipping).click();	
		
		shppingAddresshsMapObj = ReadXlsxDataHelper.getXlsxRowDataAsMap("ShppingAddress", "PrimaryAddress", 1);
		ShippingAddress.addShippingAddress(shppingAddresshsMapObj);
		
		
	}
	

}
